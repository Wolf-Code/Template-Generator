# Change Log

## [0.0.4] - 17-08-2020
### Fixed
- Missing `extends ComponentProps` on state props interface

## [0.0.3] - 17-08-2020
### Added
- Missing index.ts file

## [0.0.2] - 17-08-2020
### Added
- Path indication before creating the component

### Changed
- Removed placeholder changelog content

### Fixed
- Command was missing and therefore did not show up

## [0.0.1]
- Initial release