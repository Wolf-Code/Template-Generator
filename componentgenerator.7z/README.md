## Features

Automatically generates all files required for a component.

## Installation

Create a .vxis for local installation by running `yarn package` in the root of the project, which can then be installed inside Visual Studio Code