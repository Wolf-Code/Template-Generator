export interface IComponentFile {
	name: string
	content: string
}