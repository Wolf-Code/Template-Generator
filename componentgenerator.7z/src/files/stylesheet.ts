import { IComponentFile } from "../component-file.interface"

export default {
	name: "{name}.module.scss",
	content: `.root {

}
`
} as IComponentFile